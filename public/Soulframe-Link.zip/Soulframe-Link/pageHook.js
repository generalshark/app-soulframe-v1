// pageHook.js
// S'exécute DANS la page. Remplace window.fetch pour l'API Soulframe.

(function () {
  if (!window.fetch) return;

  const originalFetch = window.fetch.bind(window);
  let nextId = 1;

  async function soulframeLinkFetch(input, init) {
    const url = typeof input === "string" ? input : (input && input.url);

    // Si ce n'est pas un appel à l'API Soulframe → on laisse passer
    if (!url || !url.startsWith("https://api.soulframe.com/")) {
      return originalFetch(input, init);
    }

    const requestId = nextId++;

    // On prépare une promesse qui sera résolue quand le content script répondra
    const resultPromise = new Promise((resolve) => {
      function listener(event) {
        if (event.source !== window) return;
        const data = event.data;
        if (!data || data.type !== "SoulframeLink_fetch_result") return;
        if (data.requestId !== requestId) return;

        window.removeEventListener("message", listener);
        resolve(data.result);
      }

      window.addEventListener("message", listener);
    });

    // On envoie la requête vers le content script / background
    window.postMessage(
      {
        type: "SoulframeLink_fetch",
        requestId,
        url,
        init
      },
      "*"
    );

    const result = await resultPromise;

    // Si l'extension n'a pas répondu correctement : fallback sur le fetch normal
    if (!result || (result.status === 0 && !result.ok)) {
      return originalFetch(input, init);
    }

    const responseInit = {
      status: result.status,
      statusText: result.statusText,
      headers: result.headers
    };

    // On recrée un objet Response que ton code peut consommer normalement (.json(), .text(), etc.)
    return new Response(result.body, responseInit);
  }

  // On remplace fetch TÔT dans le cycle de vie de la page
  window.fetch = soulframeLinkFetch;
})();
