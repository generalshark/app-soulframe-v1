// contentScript.js
// 1) injecte pageHook.js dans la page (contexte de la page)
// 2) fait le pont entre page <-> background via postMessage / sendMessage

// Injection du script dans la page (contexte JS de la page, pas monde isolé)
const script = document.createElement("script");
script.src = chrome.runtime.getURL("pageHook.js");
script.type = "text/javascript";
(document.head || document.documentElement).appendChild(script);
script.remove();

// Pont entre la page et l'extension
window.addEventListener("message", (event) => {
  if (event.source !== window) return;

  const data = event.data;
  if (!data || data.type !== "SoulframeLink_fetch") return;

  chrome.runtime.sendMessage(
    {
      type: "SoulframeLink_fetch",
      url: data.url,
      init: data.init,
      requestId: data.requestId
    },
    (result) => {
      // On renvoie le résultat brut à la page
      window.postMessage(
        {
          type: "SoulframeLink_fetch_result",
          requestId: data.requestId,
          result
        },
        "*"
      );
    }
  );
});
