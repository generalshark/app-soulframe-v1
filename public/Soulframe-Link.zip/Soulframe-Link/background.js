// background.js
// Fait la requête vers l'API Soulframe à la place de la page

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "SoulframeLink_fetch") {
    return; // on ignore les autres messages
  }

  const url = message.url;
  const init = message.init || {};

  // Sécurité : on ne laisse passer que l'API Soulframe
  if (typeof url !== "string" || !url.startsWith("https://api.soulframe.com/")) {
    sendResponse({
      ok: false,
      status: 0,
      statusText: "Blocked: URL not allowed",
      headers: {},
      body: ""
    });
    return;
  }

  fetch(url, init)
    .then(async (response) => {
      const text = await response.text();
      const headers = {};
      for (const [key, value] of response.headers.entries()) {
        headers[key] = value;
      }

      sendResponse({
        ok: response.ok,
        status: response.status,
        statusText: response.statusText,
        headers,
        body: text
      });
    })
    .catch((error) => {
      sendResponse({
        ok: false,
        status: 0,
        statusText: error.message || String(error),
        headers: {},
        body: ""
      });
    });

  // Important : on indique à Chrome qu'on va répondre plus tard (async)
  return true;
});
